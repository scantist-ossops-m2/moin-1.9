# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - migration from base rev 1090600

    Nothing to do, we just return the new data dir revision.

    @copyright: 2013 by Thomas Waldmann
    @license: GNU GPL, see COPYING for details.
"""

def execute(script, data_dir, rev):
    return 1090700

