# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - misc. i18n related scripts

    @copyright: 2006 MoinMoin:ThomasWaldmann
    @license: GNU GPL, see COPYING for details.
"""
