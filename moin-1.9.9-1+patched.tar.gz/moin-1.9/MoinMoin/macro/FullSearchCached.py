# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - FullSearch Macro, cached version

    Refer to the FullSearch documentation for details.
    This macro is cached regardless of the validity of the data.

    @copyright: 2005 MoinMoin:AlexanderSchremmer
    @license: GNU GPL, see COPYING for details.
"""

from MoinMoin.macro.FullSearch import execute
Dependencies = []

# yes, that's all

