# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - audio/* file Filter

    @copyright: 2006 MoinMoin:ThomasWaldmann
    @license: GNU GPL, see COPYING for details.
"""

def execute(indexobj, filename):
    """ Audio data filtering not implemented yet.

        TODO: maybe extract title, artist, etc. from mp3 and ogg
    """
    return u""

