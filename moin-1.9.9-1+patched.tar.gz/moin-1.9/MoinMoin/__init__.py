# -*- coding: iso-8859-1 -*-
"""
MoinMoin - a wiki engine in Python

@copyright: 2000-2006 by Juergen Hermann <jh@web.de>,
            2002-2016 MoinMoin:ThomasWaldmann
@license: GNU GPL, see COPYING for details.
"""



