# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - image/* file Filter

    @copyright: 2006 MoinMoin:ThomasWaldmann
    @license: GNU GPL, see COPYING for details.
"""

def execute(indexobj, filename):
    """ Image data filtering not implemented yet.

        TODO: maybe extract comments or time stamps from jpegs and png.
    """
    return u""

