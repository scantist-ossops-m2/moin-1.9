# -*- coding: iso-8859-1 -*-
"""
MoinMoin OpenID Relying Party Extensions

@copyright: 2007-20099 Canonical, Inc.
@license: GNU GPL, see COPYING for details.
"""

